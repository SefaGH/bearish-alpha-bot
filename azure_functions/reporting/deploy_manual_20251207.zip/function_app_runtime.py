import json
import os
import logging
import re
import traceback
import hashlib
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple
from io import StringIO

import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.core.exceptions import ResourceExistsError, ServiceRequestError, HttpResponseError
from azure.storage.blob import BlobServiceClient, BlobLeaseClient
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.compute.models import RunCommandInput

# ============================================================================
# CONFIGURATION & VALIDATION
# ============================================================================

REQUIRED_VARS = [
    "bearishstorage_STORAGE",
    "RAW_LOGS_CONTAINER",
    "REPORTS_CONTAINER",
    "AZURE_SUBSCRIPTION_ID",
    "LOGUPLOADER_VM_NAME",
    "LOGUPLOADER_RESOURCE_GROUP",
    "LOGUPLOADER_STORAGE_ACCOUNT"
]

def validate_environment():
    """Startup environment validation with detailed error messages"""
    missing = [var for var in REQUIRED_VARS if not os.environ.get(var)]
    if missing:
        raise ValueError(f"CRITICAL: Missing environment variables: {', '.join(missing)}")
    
    sub_id = os.environ.get("AZURE_SUBSCRIPTION_ID", "")
    try:
        uuid.UUID(sub_id)
    except ValueError:
        raise ValueError(f"Invalid AZURE_SUBSCRIPTION_ID format (expected UUID): {sub_id}")
    
    storage_acc = os.environ.get("LOGUPLOADER_STORAGE_ACCOUNT", "")
    if not re.match(r'^[a-z0-9]{3,24}$', storage_acc):
        raise ValueError(f"Invalid storage account name: {storage_acc}")

try:
    validate_environment()
    logging.info("✅ Environment validation passed")
except Exception as e:
    logging.critical(f"❌ Environment validation failed: {e}")

STORAGE_CONNECTION = os.environ.get("bearishstorage_STORAGE")
RAW_LOGS_CONTAINER = os.environ.get("RAW_LOGS_CONTAINER", "raw-logs")
REPORTS_CONTAINER = os.environ.get("REPORTS_CONTAINER", "reports")
LOGUPLOADER_DEFAULT_VM = os.environ.get("LOGUPLOADER_VM_NAME")
LOGUPLOADER_DEFAULT_RG = os.environ.get("LOGUPLOADER_RESOURCE_GROUP")
SUBSCRIPTION_ID = os.environ.get("AZURE_SUBSCRIPTION_ID")
STORAGE_ACCOUNT = os.environ.get("LOGUPLOADER_STORAGE_ACCOUNT")

VM_LOG_DIR = os.environ.get("LOGUPLOADER_VM_LOG_DIR", "/mnt/bearish/logs")
LOG_FILE_PATTERN = os.environ.get("LOGUPLOADER_FILE_GLOB", "live_trading_*.log")
STORAGE_API_VERSION = os.environ.get("LOGUPLOADER_STORAGE_API_VERSION", "2021-08-06")
RUN_COMMAND_TIMEOUT = int(os.environ.get("LOGUPLOADER_TIMEOUT_SECONDS", "180"))
MAX_LOG_SIZE_BYTES = int(os.environ.get("MAX_LOG_SIZE_MB", "10")) * 1024 * 1024
LOCK_TIMEOUT_SECONDS = int(os.environ.get("LOCK_TIMEOUT_SECONDS", "300"))

LOGGER = logging.getLogger(__name__)

# ============================================================================
# SECURE BASH SCRIPT - NO INJECTION POSSIBLE
# ============================================================================

def generate_secure_bash_script() -> str:
    """
    Generate bash script with environment variables embedded at runtime.
    This is safe because we control all inputs through validated env vars.
    """
    storage_acc_env = STORAGE_ACCOUNT or ""
    if not storage_acc_env:
        raise ValueError("LOGUPLOADER_STORAGE_ACCOUNT is not set")
    if not RAW_LOGS_CONTAINER:
        raise ValueError("RAW_LOGS_CONTAINER is not set")
    if not VM_LOG_DIR:
        raise ValueError("LOGUPLOADER_VM_LOG_DIR is not set")
    if not LOG_FILE_PATTERN:
        raise ValueError("LOGUPLOADER_FILE_GLOB is not set")

    log_dir = VM_LOG_DIR.replace('"', '\\"')
    pattern = LOG_FILE_PATTERN.replace('"', '\\"')
    storage_acc = storage_acc_env.replace('"', '\\"')
    container = RAW_LOGS_CONTAINER.replace('"', '\\"')
    api_ver = STORAGE_API_VERSION.replace('"', '\\"')

    return f"""#!/bin/bash
set -euo pipefail

# Hardcoded configuration from environment
LOG_DIR="{log_dir}"
PATTERN="{pattern}"
STORAGE_ACCOUNT="{storage_acc}"
CONTAINER="{container}"
API_VERSION="{api_ver}"

# Output function for structured logging
log_json() {{
    echo "$1" >&2
    echo "$1"
}}

# 1. Find latest log file
LATEST_LOG=$(find "$LOG_DIR" -maxdepth 1 -name "$PATTERN" -type f -printf '%T@ %p\\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)

if [ -z "$LATEST_LOG" ]; then
    log_json '{{"status":"error","message":"No log files found matching pattern"}}'
    exit 1
fi

FILENAME=$(basename "$LATEST_LOG")
CONTENT_LENGTH=$(stat -c%s "$LATEST_LOG" 2>/dev/null || echo "0")

if [ "$CONTENT_LENGTH" -eq 0 ]; then
    log_json '{{"status":"error","message":"Log file is empty"}}'
    exit 1
fi

# 2. Acquire managed identity token with retries
MAX_RETRIES=3
RETRY_DELAY=2

for i in $(seq 1 $MAX_RETRIES); do
    TOKEN=$(curl -s --max-time 10 --connect-timeout 5 \
        -H "Metadata:true" \
        "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://storage.azure.com/" \
        2>/dev/null | grep -oP '(?<="access_token":")[^"]+' || echo "")
    
    if [ -n "$TOKEN" ]; then
        break
    fi
    
    if [ $i -lt $MAX_RETRIES ]; then
        log_json '{{"status":"warning","message":"Token fetch attempt '$i' failed, retrying..."}}'
        sleep $RETRY_DELAY
    else
        log_json '{{"status":"error","message":"Failed to acquire managed identity token after '$MAX_RETRIES' attempts"}}'
        exit 1
    fi
done

# 3. Upload to blob storage
BLOB_URL="https://$STORAGE_ACCOUNT.blob.core.windows.net/$CONTAINER/$FILENAME"
UPLOAD_DATE=$(date -u +"%a, %d %b %Y %H:%M:%S GMT")

HTTP_CODE=$(curl -X PUT "$BLOB_URL" \
    -H "Authorization: Bearer $TOKEN" \
    -H "x-ms-blob-type: BlockBlob" \
    -H "x-ms-version: $API_VERSION" \
    -H "x-ms-date: $UPLOAD_DATE" \
    -H "Content-Length: $CONTENT_LENGTH" \
    -H "Content-Type: text/plain; charset=utf-8" \
    --data-binary "@$LATEST_LOG" \
    --max-time 120 \
    -s -o /dev/null -w "%{{http_code}}" 2>/dev/null || echo "000")

if [ "$HTTP_CODE" = "201" ]; then
    log_json '{{"status":"success","file":"'"$FILENAME"'","size":'"$CONTENT_LENGTH"',"upload_date":"'"$UPLOAD_DATE"'"}}'
    exit 0
elif [ "$HTTP_CODE" = "409" ]; then
    log_json '{{"status":"warning","message":"File already exists (HTTP 409)","file":"'"$FILENAME"'"}}'
    exit 0
else
    log_json '{{"status":"error","message":"Upload failed","http_code":"'"$HTTP_CODE"'","file":"'"$FILENAME"'"}}'
    exit 1
fi
"""

# ============================================================================
# DISTRIBUTED LOCK FOR CONCURRENT EXECUTION PREVENTION
# ============================================================================

class DistributedLock:
    """Blob lease-based distributed lock to prevent concurrent execution"""
    
    def __init__(self, blob_service_client: BlobServiceClient, lock_name: str):
        self.container_name = "system-locks"
        self.blob_name = f"{lock_name}.lock"
        self.blob_service = blob_service_client
        self.lease_client = None
        self.acquired = False
        
    def __enter__(self):
        """Acquire lock with automatic container creation"""
        try:
            # Ensure container exists
            container_client = self.blob_service.get_container_client(self.container_name)
            try:
                container_client.create_container()
            except ResourceExistsError:
                pass
            
            # Create or get lock blob
            blob_client = container_client.get_blob_client(self.blob_name)
            try:
                blob_client.upload_blob(b"lock", overwrite=False)
            except ResourceExistsError:
                pass
            
            # Acquire lease
            self.lease_client = BlobLeaseClient(blob_client)
            self.lease_client.acquire(timeout=LOCK_TIMEOUT_SECONDS)
            self.acquired = True
            LOGGER.info(f"🔒 Lock acquired: {self.blob_name}")
            return self
            
        except Exception as e:
            LOGGER.warning(f"⚠️ Failed to acquire lock: {e}")
            raise
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Release lock"""
        if self.acquired and self.lease_client:
            try:
                self.lease_client.release()
                LOGGER.info(f"🔓 Lock released: {self.blob_name}")
            except Exception as e:
                LOGGER.error(f"Error releasing lock: {e}")

# ============================================================================
# OPTIMIZED LOG ANALYSIS - SINGLE PASS PARSING
# ============================================================================

class StreamingLogAnalyzer:
    """Memory-efficient single-pass log analyzer"""
    
    def __init__(self):
        self.stats = {
            'iterations': 0,
            'failures': defaultdict(int),
            'strategies': defaultdict(lambda: {'attempts': 0}),
            'ppo': {'signals': 0, 'above_threshold': 0},
            'rsi_values': [],
            'volume_data': [],
            'regimes': [],
            'trades': []
        }
        
        # Compile regex patterns once for performance
        self.patterns = {
            'iteration': re.compile(r'\[ITERATION (\d+)\]'),
            'volume_fail': re.compile(r'Volume confirmation failed'),
            'rsi_fail': re.compile(r'RSI .* is below the threshold'),
            'rip_fail': re.compile(r'Rip Check Failed'),
            'ppo_weak': re.compile(r'Ignored weak PPO signal.*Conf: (\d+\.\d+) < 0\.75'),
            'adaptive_ob': re.compile(r'\[ADAPTIVE_OB/'),
            'adaptive_str': re.compile(r'\[ADAPTIVE_STR/'),
            'ppo_conf': re.compile(r'PPO-MONITOR.*Conf: (\d+\.\d+)'),
            'rsi_value': re.compile(r'RSI \((\d+\.?\d*)\)'),
            'volume': re.compile(r'current=(\d+), avg=(\d+)'),
            'regime': re.compile(r'Prediction: (\w+) \(confidence: (\d+\.\d+)\)'),
            'trade_closed': re.compile(r'TRADE_CLOSED\s+(\{.*?\})'),
        }
    
    def analyze_stream(self, content: str, max_lines: int = 50000) -> Dict[str, Any]:
        """
        Single-pass streaming analysis with line limit to prevent OOM.
        Processes logs line-by-line instead of multiple full-content scans.
        """
        lines_processed = 0
        
        for line in content.split('\n'):
            if lines_processed >= max_lines:
                LOGGER.warning(f"⚠️ Line limit reached ({max_lines}), truncating analysis")
                break
            
            lines_processed += 1
            
            # Count iterations
            if self.patterns['iteration'].search(line):
                self.stats['iterations'] += 1
            
            # Failures
            if self.patterns['volume_fail'].search(line):
                self.stats['failures']['volume_confirmation'] += 1
            if self.patterns['rsi_fail'].search(line):
                self.stats['failures']['rsi_threshold'] += 1
            if self.patterns['rip_fail'].search(line):
                self.stats['failures']['rip_check'] += 1
            
            # PPO weak signals
            ppo_match = self.patterns['ppo_weak'].search(line)
            if ppo_match:
                self.stats['failures']['ppo_confidence'] += 1
            
            # Strategies
            if self.patterns['adaptive_ob'].search(line):
                self.stats['strategies']['adaptive_ob']['attempts'] += 1
            if self.patterns['adaptive_str'].search(line):
                self.stats['strategies']['adaptive_str']['attempts'] += 1
            
            # PPO monitoring
            ppo_conf_match = self.patterns['ppo_conf'].search(line)
            if ppo_conf_match:
                conf = float(ppo_conf_match.group(1))
                self.stats['ppo']['signals'] += 1
                if conf >= 0.75:
                    self.stats['ppo']['above_threshold'] += 1
            
            # Market data (sample, don't store all)
            rsi_match = self.patterns['rsi_value'].search(line)
            if rsi_match and len(self.stats['rsi_values']) < 1000:  # Limit samples
                self.stats['rsi_values'].append(float(rsi_match.group(1)))
            
            vol_match = self.patterns['volume'].search(line)
            if vol_match and len(self.stats['volume_data']) < 1000:
                self.stats['volume_data'].append((int(vol_match.group(1)), int(vol_match.group(2))))
            
            regime_match = self.patterns['regime'].search(line)
            if regime_match:
                self.stats['regimes'].append(regime_match.group(1))
            
            # Trades
            trade_match = self.patterns['trade_closed'].search(line)
            if trade_match:
                try:
                    trade_data = json.loads(trade_match.group(1))
                    self.stats['trades'].append(trade_data)
                except json.JSONDecodeError:
                    pass
        
        return self._compile_results()
    
    def _compile_results(self) -> Dict[str, Any]:
        """Compile streaming results into final analysis"""
        total_iter = self.stats['iterations']
        
        return {
            'total_iterations': total_iter,
            'failure_categories': dict(self.stats['failures']),
            'strategy_performance': dict(self.stats['strategies']) | {'ppo': self.stats['ppo']},
            'market_conditions': {
                'rsi_stats': {
                    'avg': sum(self.stats['rsi_values']) / len(self.stats['rsi_values']) if self.stats['rsi_values'] else 0,
                    'samples': len(self.stats['rsi_values'])
                },
                'volume_stats': {
                    'current_avg': sum(v[0] for v in self.stats['volume_data']) / len(self.stats['volume_data']) if self.stats['volume_data'] else 0,
                },
                'dominant_regime': max(set(self.stats['regimes']), key=self.stats['regimes'].count) if self.stats['regimes'] else 'unknown'
            },
            'has_trades': len(self.stats['trades']) > 0,
            'trades': self.stats['trades']
        }

# ============================================================================
# REPORT GENERATION WITH XSS PROTECTION
# ============================================================================

class SecureHTMLReportGenerator:
    """HTML report generator with XSS protection"""
    
    @staticmethod
    def escape_html(text: str) -> str:
        """Escape HTML special characters to prevent XSS"""
        return (text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&#x27;"))
    
    def generate(self, base: Dict[str, Any], sig: Dict[str, Any], recs: List[Dict[str, Any]]) -> str:
        """Generate secure HTML report using string builder pattern"""
        output = StringIO()
        
        # Escape all user-controlled data
        run_id = self.escape_html(str(base.get('run_id', 'Unknown')))
        report_filename = self.escape_html(str(base.get('report_filename', 'Unknown')))
        message = self.escape_html(str(base.get('message', '')))
        
        output.write(f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bearish Bot Raporu</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            color: #1a202c;
        }}
        .container {{ 
            max-width: 900px; 
            margin: 0 auto; 
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        .header {{ 
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white; 
            padding: 30px;
            border-bottom: 4px solid #3b82f6;
        }}
        .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
        .header .meta {{ font-size: 13px; opacity: 0.8; font-family: 'Courier New', monospace; }}
        .content {{ padding: 30px; }}
        .card {{ 
            border: 2px solid #e5e7eb; 
            padding: 20px; 
            margin-bottom: 20px; 
            border-radius: 12px;
            background: #fafafa;
        }}
        .card.success {{ background: #f0fdf4; border-color: #22c55e; }}
        .card.warning {{ background: #fffbeb; border-color: #f59e0b; }}
        .card.info {{ background: #eff6ff; border-color: #3b82f6; }}
        .card h3 {{ margin-bottom: 15px; font-size: 18px; color: #1e293b; }}
        .stat-grid {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 15px; 
            margin-top: 15px; 
        }}
        .stat-box {{ 
            background: white; 
            padding: 15px; 
            border-radius: 8px; 
            text-align: center;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }}
        .stat-val {{ 
            font-size: 24px; 
            font-weight: 700; 
            color: #1e293b; 
            display: block;
            margin-bottom: 5px;
        }}
        .stat-lbl {{ font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }}
        .tag {{ 
            display: inline-block;
            padding: 4px 12px; 
            border-radius: 20px; 
            font-size: 11px; 
            font-weight: 700; 
            color: white;
            margin-right: 8px;
        }}
        .tag-HIGH {{ background: #dc2626; }} 
        .tag-MEDIUM {{ background: #d97706; }} 
        .tag-LOW {{ background: #16a34a; }}
        .recommendation {{ 
            margin: 15px 0; 
            padding: 15px; 
            background: white;
            border-radius: 8px;
            border-left: 4px solid #3b82f6;
        }}
        .footer {{ 
            text-align: center; 
            padding: 20px; 
            background: #f9fafb; 
            border-top: 1px solid #e5e7eb;
            font-size: 12px;
            color: #64748b;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Bearish Alpha Bot - Analiz Raporu</h1>
            <div class="meta">
                Run ID: {run_id}<br>
                Rapor: {report_filename}<br>
                Oluşturulma: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}
            </div>
        </div>
        
        <div class="content">
            <div class="card {'success' if base.get('trade_count', 0) > 0 else 'warning'}">
                <h3>📊 Çalıştırma Özeti</h3>
                <p style="margin-bottom: 15px;">{message}</p>
                <div class="stat-grid">
                    <div class="stat-box">
                        <span class="stat-val">{base.get('trade_count', 0)}</span>
                        <span class="stat-lbl">İşlem Sayısı</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-val">{base.get('total_pnl', 0):.2f}</span>
                        <span class="stat-lbl">Toplam PnL (USDT)</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-val">{base.get('win_rate', 0):.1f}%</span>
                        <span class="stat-lbl">Win Rate</span>
                    </div>
                </div>
            </div>
""")
        
        # Signal Analysis Section
        output.write(f"""
            <div class="card info">
                <h3>🔍 Sinyal & Piyasa Analizi</h3>
                <p><strong>Toplam Döngü:</strong> {sig.get('total_iterations', 0)} | 
                   <strong>Rejim:</strong> {self.escape_html(sig.get('market_conditions', {}).get('dominant_regime', 'N/A').upper())}</p>
                <div class="stat-grid">
                    <div class="stat-box">
                        <span class="stat-val">{sig.get('market_conditions', {}).get('rsi_stats', {}).get('avg', 0):.1f}</span>
                        <span class="stat-lbl">Ortalama RSI</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-val">{sig.get('strategy_performance', {}).get('ppo', {}).get('signals', 0)}</span>
                        <span class="stat-lbl">PPO Sinyali</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-val">{sig.get('market_conditions', {}).get('volume_stats', {}).get('current_avg', 0):.0f}</span>
                        <span class="stat-lbl">Ortalama Hacim</span>
                    </div>
                </div>
                
                <h4 style="margin-top: 20px; margin-bottom: 10px;">🚫 Engellenen Sinyaller</h4>
                <ul style="margin-left: 20px; line-height: 1.8;">
""")
        
        for cat, count in sig.get('failure_categories', {}).items():
            if count > 0:
                output.write(f"<li>{self.escape_html(cat.replace('_', ' ').title())}: {count} kez</li>\n")
        
        output.write("</ul></div>\n")
        
        # Recommendations Section
        if recs:
            output.write("""
            <div class="card warning">
                <h3>💡 Optimizasyon Önerileri</h3>
""")
            for r in recs:
                urgency = self.escape_html(str(r.get('urgency', 'LOW')))
                param = self.escape_html(str(r.get('parameter', '')))
                current = self.escape_html(str(r.get('current', '')))
                suggested = self.escape_html(str(r.get('suggested', '')))
                reason = self.escape_html(str(r.get('reason', '')))
                impact = self.escape_html(str(r.get('expected_impact', '')))
                
                output.write(f"""
                <div class="recommendation">
                    <span class="tag tag-{urgency}">{urgency}</span>
                    <strong>{param}</strong>: {current} → <strong>{suggested}</strong><br>
                    <small style="color: #64748b;"><em>{reason}</em> | Beklenen Etki: {impact}</small>
                </div>
""")
            output.write("</div>\n")
        
        output.write("""
        </div>
        
        <div class="footer">
            Generated by Bearish Alpha Bot Analytics Engine v10 | 
            Powered by Azure Functions
        </div>
    </div>
</body>
</html>
""")
        
        return output.getvalue()

# ============================================================================
# MAIN ANALYSIS LOGIC
# ============================================================================

def analyze_trading_logs(content: str, filename: str = "") -> Dict[str, Any]:
    """
    Main log analysis function with enhanced error handling and performance.
    """
    stats = {
        "status": "no_data",
        "trade_count": 0,
        "total_pnl": 0.0,
        "win_rate": 0.0,
        "message": "Log içeriği boş veya analiz edilemedi.",
        "run_id": "UNKNOWN",
        "report_filename": "UNKNOWN",
        "events_count": 0,
        "signal_analysis": {},
        "optimization_recommendations": [],
        "has_trades": False,
        "html_report": "",
        "processing_time_ms": 0
    }
    
    start_time = time.time()
    
    if not content or len(content.strip()) == 0:
        LOGGER.warning("Empty log content received")
        return stats
    
    try:
        # Run ID detection
        run_id_match = re.search(r"runId[\"':\s]+([a-zA-Z0-9\-_]+)", content)
        if run_id_match:
            stats["run_id"] = run_id_match.group(1)
        
        # Generate report filename
        match = re.search(r"live_trading_(\d{8}_\d{6}_\d+)\.log", filename)
        if match:
            file_id = match.group(1)
            if stats["run_id"] == "UNKNOWN":
                stats["run_id"] = file_id
            stats["report_filename"] = f"report_{file_id}.html"
        else:
            ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
            stats["report_filename"] = f"report_{ts}.html"
        
        # Trade detection from summary
        summary_match = re.search(r"Total Exits:\s*(\d+)", content)
        if summary_match and int(summary_match.group(1)) > 0:
            stats["trade_count"] = int(summary_match.group(1))
            
            pnl_match = re.search(r"Total P&L:\s*\S+\s*([+\-]?\d+\.\d+)", content)
            if pnl_match:
                stats["total_pnl"] = float(pnl_match.group(1))
            
            wr_match = re.search(r"Win Rate:\s*(\d+\.\d+)%", content)
            if wr_match:
                stats["win_rate"] = float(wr_match.group(1))
            
            stats["status"] = "success"
            stats["has_trades"] = True
        
        # Signal analysis using optimized streaming analyzer
        analyzer = StreamingLogAnalyzer()
        sig_analysis = analyzer.analyze_stream(content)
        stats["signal_analysis"] = sig_analysis
        stats["events_count"] = sig_analysis.get('total_iterations', 0)
        
        # Process individual trades if not found in summary
        if not stats["has_trades"] and sig_analysis.get('trades'):
            trades = sig_analysis['trades']
            pnl_sum = sum(float(t.get("pnl_usd", 0)) for t in trades)
            wins = sum(1 for t in trades if float(t.get("pnl_usd", 0)) > 0)
            
            stats["trade_count"] = len(trades)
            stats["total_pnl"] = round(pnl_sum, 4)
            stats["win_rate"] = round((wins / len(trades)) * 100, 2) if trades else 0.0
            stats["status"] = "success"
            stats["has_trades"] = True
        
        # Generate optimization recommendations if no trades
        recs = []
        if not stats["has_trades"]:
            optimizer = OptimizationRecommender()
            recs = optimizer.generate_recommendations(sig_analysis)
            stats["optimization_recommendations"] = recs
            
            # Set appropriate status
            if sig_analysis.get('total_iterations', 0) > 0:
                stats["status"] = "signals_only"
                stats["message"] = "Bot çalıştı ancak işlem kriterleri sağlanamadı."
        else:
            stats["message"] = f"✅ {stats['trade_count']} işlem tamamlandı. PnL: {stats['total_pnl']:.2f} USDT"
        
        # Generate HTML report
        html_gen = SecureHTMLReportGenerator()
        stats["html_report"] = html_gen.generate(stats, sig_analysis, recs)
        
        # Calculate processing time
        stats["processing_time_ms"] = int((time.time() - start_time) * 1000)
        
        return stats
        
    except Exception as e:
        LOGGER.error(f"Analysis error: {str(e)}\n{traceback.format_exc()}")
        stats["status"] = "error"
        stats["message"] = f"Analiz hatası: {str(e)}"
        stats["processing_time_ms"] = int((time.time() - start_time) * 1000)
        return stats

# ============================================================================
# OPTIMIZATION RECOMMENDER (unchanged but included for completeness)
# ============================================================================

class OptimizationRecommender:
    """Generate parameter optimization recommendations based on signal analysis"""
    
    def generate_recommendations(self, analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        recs = []
        fails = analysis.get('failure_categories', {})
        total_iter = analysis.get('total_iterations', 0)
        
        if total_iter <= 0:
            return recs
        
        # Volume confirmation failures
        if fails.get('volume_confirmation', 0) / total_iter > 0.5:
            recs.append({
                'parameter': 'volume_factor',
                'current': 1.5,
                'suggested': 1.2,
                'reason': f"Hacim şartı {fails['volume_confirmation']}/{total_iter} kez sağlanamadı",
                'urgency': 'HIGH',
                'expected_impact': 'Sinyal üretimini %30-40 artırabilir'
            })
        
        # RSI threshold failures
        if fails.get('rsi_threshold', 0) / total_iter > 0.6:
            recs.append({
                'parameter': 'RSI_THRESHOLD_BTC',
                'current': 50,
                'suggested': 45,
                'reason': f"RSI eşiği {fails['rsi_threshold']}/{total_iter} kez aşılamadı",
                'urgency': 'MEDIUM',
                'expected_impact': 'Short sinyallerini artırır'
            })
        
        # PPO confidence threshold
        ppo = analysis.get('strategy_performance', {}).get('ppo', {})
        if ppo.get('signals', 0) > 0:
            threshold_ratio = ppo.get('above_threshold', 0) / ppo.get('signals', 1)
            if threshold_ratio < 0.3:
                recs.append({
                    'parameter': 'PPO_CONFIDENCE_THRESHOLD',
                    'current': 0.75,
                    'suggested': 0.65,
                    'reason': f"PPO sinyallerinin %{(1-threshold_ratio)*100:.0f}'i güven eşiğinin altında",
                    'urgency': 'LOW',
                    'expected_impact': 'ML katılımını artırır'
                })
        
        return recs

# ============================================================================
# AZURE FUNCTIONS ENDPOINTS
# ============================================================================

def _fetch_latest_log_with_retry(credential, max_retries: int = 3) -> Tuple[Optional[str], str]:
    """Fetch latest log from blob storage with retry logic and error handling"""
    
    for attempt in range(max_retries):
        try:
            service = BlobServiceClient(
                account_url=f"https://{STORAGE_ACCOUNT}.blob.core.windows.net",
                credential=credential
            )
            container = service.get_container_client(RAW_LOGS_CONTAINER)
            
            # List blobs with timeout
            blobs = list(container.list_blobs())
            if not blobs:
                LOGGER.warning("No blobs found in container")
                return None, ""
            
            # Get latest blob
            latest_blob = max(blobs, key=lambda b: b.last_modified)
            
            # Size check
            if latest_blob.size > MAX_LOG_SIZE_BYTES:
                LOGGER.error(f"Log file too large: {latest_blob.size} bytes (max: {MAX_LOG_SIZE_BYTES})")
                return None, ""
            
            LOGGER.info(f"Downloading: {latest_blob.name} ({latest_blob.size} bytes)")
            
            # Download with error handling
            client = container.get_blob_client(latest_blob.name)
            download_stream = client.download_blob(max_concurrency=2)
            
            # Read with encoding fallback
            try:
                content = download_stream.readall().decode('utf-8')
            except UnicodeDecodeError:
                LOGGER.warning("UTF-8 decode failed, trying latin-1")
                content = download_stream.readall().decode('latin-1')
            
            return content, latest_blob.name
            
        except HttpResponseError as e:
            LOGGER.error(f"HTTP error (attempt {attempt + 1}/{max_retries}): {e.status_code} - {e.message}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                return None, ""
                
        except Exception as e:
            LOGGER.error(f"Fetch error (attempt {attempt + 1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                return None, ""
    
    return None, ""

def _upload_report_with_retry(credential, filename: str, report_data: Dict[str, Any], max_retries: int = 3):
    """Upload analysis report with retry logic"""
    
    for attempt in range(max_retries):
        try:
            service = BlobServiceClient(
                account_url=f"https://{STORAGE_ACCOUNT}.blob.core.windows.net",
                credential=credential
            )
            container = service.get_container_client(REPORTS_CONTAINER)
            
            # Ensure container exists
            try:
                container.create_container()
            except ResourceExistsError:
                pass
            
            # Upload both JSON and HTML versions
            json_filename = filename.replace('.html', '.json')
            html_filename = filename if filename.endswith('.html') else f"{filename}.html"
            
            # Upload JSON
            json_blob = container.get_blob_client(json_filename)
            json_content = json.dumps(report_data, ensure_ascii=False, indent=2)
            json_blob.upload_blob(json_content, overwrite=True, content_type='application/json')
            
            # Upload HTML
            html_blob = container.get_blob_client(html_filename)
            html_content = report_data.get('html_report', '')
            if html_content:
                html_blob.upload_blob(html_content, overwrite=True, content_type='text/html')
            
            LOGGER.info(f"✅ Reports uploaded: {json_filename}, {html_filename}")
            return
            
        except Exception as e:
            LOGGER.error(f"Upload error (attempt {attempt + 1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise

# Main HTTP endpoint for report generation
def run_report_logic(req: func.HttpRequest) -> func.HttpResponse:
    """
    Main endpoint for log analysis and report generation.
    Includes distributed lock to prevent concurrent execution.
    """
    LOGGER.info("🚀 Report generation started (V10)")
    
    try:
        req_body = req.get_json()
    except ValueError:
        req_body = {}
    
    log_content = req_body.get("log_content", "")
    incoming_run_id = req_body.get("run_id")
    filename = ""
    
    # Credential setup
    credential = DefaultAzureCredential(
        exclude_shared_token_cache_credential=True,
        exclude_interactive_browser_credential=True
    )
    
    # Distributed lock to prevent concurrent execution
    try:
        blob_service = BlobServiceClient(
            account_url=f"https://{STORAGE_ACCOUNT}.blob.core.windows.net",
            credential=credential
        )
        
        lock_name = "report-generation"
        with DistributedLock(blob_service, lock_name):
            # Fetch log if not provided
            if not log_content:
                log_content, filename = _fetch_latest_log_with_retry(credential)
                
                if not log_content:
                    return func.HttpResponse(
                        json.dumps({"status": "error", "message": "No log data available"}),
                        status_code=404,
                        mimetype="application/json"
                    )
            
            # Analyze logs
            analysis = analyze_trading_logs(log_content, filename)
            
            # Override run_id if provided
            if analysis.get("run_id") == "UNKNOWN" and incoming_run_id:
                analysis["run_id"] = incoming_run_id
            
            # Upload report
            try:
                _upload_report_with_retry(credential, analysis["report_filename"], analysis)
            except Exception as e:
                LOGGER.error(f"Report upload failed: {e}")
                analysis["upload_status"] = "failed"
            
            # Determine HTTP status code
            if analysis["status"] == "success":
                status_code = 200
            elif analysis["status"] == "signals_only":
                status_code = 202
            else:
                status_code = 202
            
            LOGGER.info(f"✅ Report generated in {analysis['processing_time_ms']}ms")
            
            return func.HttpResponse(
                json.dumps(analysis, ensure_ascii=False),
                status_code=status_code,
                mimetype="application/json"
            )
            
    except Exception as e:
        LOGGER.exception("Fatal error in report generation")
        return func.HttpResponse(
            json.dumps({
                "status": "error",
                "message": str(e),
                "traceback": traceback.format_exc()
            }),
            status_code=500,
            mimetype="application/json"
        )

# VM log uploader endpoint
def log_uploader_http(req: func.HttpRequest) -> func.HttpResponse:
    """
    Endpoint to trigger log upload from VM to blob storage.
    Uses RunCommand to execute secure bash script on VM.
    """
    LOGGER.info("🔄 Log uploader triggered")
    
    try:
        body = req.get_json()
    except ValueError:
        body = {}
    
    vm_name = body.get("vmName") or req.params.get("vmName") or LOGUPLOADER_DEFAULT_VM
    resource_group = body.get("resourceGroup") or req.params.get("resourceGroup") or LOGUPLOADER_DEFAULT_RG
    
    if not vm_name or not resource_group:
        return func.HttpResponse(
            json.dumps({
                "status": "error",
                "message": "Missing vmName or resourceGroup parameters"
            }),
            status_code=400,
            mimetype="application/json"
        )
    
    try:
        # Execute VM command
        command_result = _invoke_vm_log_sync(vm_name, resource_group)
        vm_payload = _parse_vm_output(command_result) or {}
        
        status = vm_payload.get("status", "error")
        http_code = 200 if status == "success" else 500
        
        response = {
            "status": status,
            "vm": vm_name,
            "resourceGroup": resource_group,
            "vmPayload": vm_payload,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        LOGGER.info(f"VM command completed: {status}")
        
        return func.HttpResponse(
            json.dumps(response, ensure_ascii=False),
            status_code=http_code,
            mimetype="application/json"
        )
        
    except Exception as exc:
        LOGGER.exception("LogUploader failed")
        return func.HttpResponse(
            json.dumps({
                "status": "error",
                "message": str(exc),
                "traceback": traceback.format_exc()
            }),
            status_code=500,
            mimetype="application/json"
        )

def _invoke_vm_log_sync(vm_name: str, resource_group: str):
    """Execute secure bash script on VM using RunCommand"""
    
    if not SUBSCRIPTION_ID:
        raise ValueError("AZURE_SUBSCRIPTION_ID is not set")

    credential = DefaultAzureCredential(
        exclude_interactive_browser_credential=True,
        exclude_shared_token_cache_credential=True
    )
    compute_client = ComputeManagementClient(credential, SUBSCRIPTION_ID)
    
    # Generate secure script with embedded configuration
    script_content = generate_secure_bash_script()
    
    command_input = RunCommandInput(
        command_id="RunShellScript",
        script=[script_content]
    )
    
    LOGGER.info(f"Executing RunCommand on {resource_group}/{vm_name}")
    
    poller = compute_client.virtual_machines.begin_run_command(
        resource_group_name=resource_group,
        vm_name=vm_name,
        parameters=command_input
    )
    
    return poller.result(timeout=RUN_COMMAND_TIMEOUT)

def _parse_vm_output(result) -> Dict[str, Any]:
    """Parse VM command output (handles both stdout and stderr)"""
    if not result or not getattr(result, "value", None):
        return {"status": "error", "message": "VM RunCommand returned no output"}

    message = result.value[0].message or ""

    if "[stdout]" in message and "[stderr]" in message:
        stdout_section = message.split("[stdout]", 1)[1].split("[stderr]", 1)[0].strip()
        stdout_section = stdout_section.replace("Enable succeeded:", "", 1).strip()
    else:
        stdout_section = message.strip()

    if not stdout_section:
        return {"status": "error", "message": "Empty VM output"}

    try:
        return json.loads(stdout_section)
    except json.JSONDecodeError:
        return {"status": "error", "message": "Failed to parse VM output", "rawOutput": stdout_section[:500]}